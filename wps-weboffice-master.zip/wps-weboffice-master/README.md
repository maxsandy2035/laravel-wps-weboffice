# WPS WebOffice Laravel Package

A comprehensive Laravel package for integrating WPS WebOffice (金山文档) into your Laravel application. This package provides seamless integration with WPS WebOffice API, enabling online document viewing, editing, and collaboration features for Word, Excel, PowerPoint, and PDF files.

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Requirements](#requirements)
- [Installation](#installation)
- [Configuration](#configuration)
- [Quick Start](#quick-start)
- [Architecture](#architecture)
- [API Endpoints](#api-endpoints)
- [Implementation Guide](#implementation-guide)
- [File Structure](#file-structure)
- [Usage Examples](#usage-examples)
- [Security](#security)
- [Troubleshooting](#troubleshooting)

## 🎯 Overview

This package acts as a bridge between your Laravel application and WPS WebOffice services. It handles:

- **Document Management**: Upload, view, edit, and manage office documents
- **Version Control**: Track document versions and history
- **User Authentication**: Secure user authentication and authorization
- **Collaboration**: Real-time collaboration features
- **File Operations**: Rename, download, and manage office files
- **Watermarking**: Add watermarks to documents
- **Access Control**: Configure user permissions (read/edit)

### Supported File Formats

- **Word Documents**: `.doc`, `.docx`, `.dot`, `.dotx`, `.docm`, `.dotm`, `.wps`, `.wpt`, `.txt`
- **Excel Spreadsheets**: `.xls`, `.xlsx`, `.xlt`, `.xltx`, `.xlsm`, `.xltm`, `.et`, `.csv`
- **PowerPoint Presentations**: `.ppt`, `.pptx`, `.pptm`, `.pps`, `.ppsx`, `.ppsm`, `.potx`, `.potm`, `.dpt`, `.dps`
- **PDF Documents**: `.pdf`

## ✨ Features

- ✅ **Online Document Viewing**: View documents directly in the browser without downloading
- ✅ **Online Document Editing**: Edit documents in real-time using WPS WebOffice
- ✅ **Version History**: Track and manage document versions
- ✅ **User Authentication**: Secure token-based authentication
- ✅ **Permission Management**: Control read/write permissions per user
- ✅ **Watermarking**: Add customizable watermarks to documents
- ✅ **User ACL**: Fine-grained access control (rename, history, copy, export, print)
- ✅ **Collaboration Tracking**: Monitor who is currently viewing/editing documents
- ✅ **File Renaming**: Rename documents through the API
- ✅ **Morphable Resources**: Support polymorphic relationships for flexible resource management

## 📦 Requirements

- **PHP**: >= 7.1.3
- **Laravel Framework**: ^5.5 | ^6.0 | ^7.0
- **Composer**: For dependency management
- **WPS WebOffice Account**: You need to register and obtain `APPID` and `APPKEY` from WPS

## 🚀 Installation

### Step 1: Install via Composer

```bash
composer require eiixy/wps-weboffice
```

### Step 2: Publish Configuration

Publish the configuration file to your Laravel application:

```bash
php artisan vendor:publish --provider="Eiixy\WebOffice\Providers\WebOfficeServiceProvider"
```

This will create `config/weboffice.php` in your Laravel application.

### Step 3: Run Migrations

Run the database migrations to create the necessary tables:

```bash
php artisan migrate
```

This will create two tables:
- `web_office_resources` - Stores document metadata
- `web_office_resource_versions` - Stores document version history

### Step 4: Configure Environment Variables

Add the following to your `.env` file:

```env
WPS_APPID=your_wps_app_id_here
WPS_APPKEY=your_wps_app_key_here
WPS_DOMAINS_VIEW=https://wwo.wps.cn/office
```

**Note**: You need to register at [WPS Developer Platform](https://open.wps.cn/) to obtain your `APPID` and `APPKEY`.

## ⚙️ Configuration

The configuration file `config/weboffice.php` contains:

```php
return [
    // WPS Application ID
    'appid' => env('WPS_APPID'),
    
    // WPS Application Key
    'appkey' => env('WPS_APPKEY'),
    
    // Your custom handler service class
    'handler' => \App\Services\WebOfficeService::class,
    
    // WPS WebOffice domain
    'domains' => [
        'view' => env('WPS_DOMAINS_VIEW', 'https://wwo.wps.cn/office'),
    ],
    
    // Supported file formats by type
    'file_formats' => [
        's' => [ // Spreadsheet (Excel)
            'r' => ['xls', 'xlt', 'et', 'xlsx', 'xltx', 'csv', 'xlsm', 'xltm'],
            'w' => ['xls', 'xlt', 'et', 'xlsx', 'xltx', 'csv', 'xlsm', 'xltm']
        ],
        'w' => [ // Word
            'r' => ['doc', 'dot', 'wps', 'wpt', 'docx', 'dotx', 'docm', 'dotm'],
            'w' => ['doc', 'dotx', 'txt', 'dot', 'wps', 'wpt', 'docx', 'docm', 'dotm']
        ],
        'p' => [ // Presentation (PowerPoint)
            'r' => ['ppt', 'pptx', 'pptm', 'ppsx', 'ppsm', 'pps', 'potx', 'potm', 'dpt', 'dps'],
            'w' => ['ppt', 'pptx', 'pptm', 'ppsx', 'ppsm', 'pps', 'potx', 'potm', 'dpt', 'dps']
        ],
        'f' => [ // PDF
            'r' => ['pdf'],
            'w' => ['pdf']
        ]
    ]
];
```

## 🏃 Quick Start

### Step 1: Create Your Handler Service

Create a service class that extends `WebOfficeHandlerService`:

```bash
php artisan make:service WebOfficeService
```

Then implement the abstract methods:

```php
<?php

namespace App\Services;

use Eiixy\WebOffice\Services\WebOfficeHandlerService;
use Eiixy\WebOffice\File;
use Eiixy\WebOffice\User;
use Eiixy\WebOffice\Users;
use Eiixy\WebOffice\Models\WebOfficeResource;

class WebOfficeService extends WebOfficeHandlerService
{
    public function authUser($token): User
    {
        // Implement your authentication logic
        // Decode token, validate, and return User object
    }

    public function fileInfo($file_id): File
    {
        // Retrieve file metadata from database
    }

    public function UserInfo(array $ids): Users
    {
        // Get user information by IDs
    }

    // ... implement other abstract methods
}
```

See `EXAMPLE_IMPLEMENTATION.php` for a complete example.

### Step 2: Update Configuration

Update `config/weboffice.php` to use your handler:

```php
'handler' => \App\Services\WebOfficeService::class,
```

### Step 3: Generate Document URL

In your controller or service:

```php
use Eiixy\WebOffice\Services\WebOfficeService;

$webOfficeService = app(WebOfficeService::class);
$file = $webOfficeService->fileInfo($file_id);
$url = $webOfficeService->getFileUrl($file, $auth_id, 'read'); // or 'write' for editing
```

## 🏗️ Architecture

### Package Structure

```
wps-weboffice/
├── config/
│   └── weboffice.php          # Package configuration
├── database/
│   └── migrations/            # Database migrations
├── routes/
│   └── wps.php                # WPS callback routes
├── src/
│   ├── Exceptions/
│   │   └── WebOfficeException.php
│   ├── Http/
│   │   └── Controllers/
│   │       └── WebOfficeController.php
│   ├── Models/
│   │   ├── WebOfficeResource.php
│   │   └── WebOfficeResourceVersion.php
│   ├── Providers/
│   │   └── WebOfficeServiceProvider.php
│   ├── Services/
│   │   ├── WebOfficeHandlerService.php
│   │   └── WebOfficeService.php
│   ├── File.php               # File data object
│   ├── User.php               # User data object
│   ├── Users.php              # Users collection
│   ├── WebOffice.php          # Utility class
│   └── WebOfficeInterface.php # Service interface
└── README.md
```

### Core Components

1. **WebOfficeHandlerService**: Abstract base class with common functionality
   - Signature generation and validation
   - File URL generation
   - File type detection

2. **WebOfficeController**: Handles WPS callback requests
   - Validates signatures
   - Routes requests to handler service
   - Returns JSON responses

3. **Models**: Eloquent models for database operations
   - `WebOfficeResource`: Main document resource model
   - `WebOfficeResourceVersion`: Document version history

4. **Data Objects**: Simple data transfer objects
   - `File`: Represents a document file
   - `User`: Represents a user
   - `Users`: Collection of users

## 🔌 API Endpoints

The package automatically registers the following routes under `/v1/3rd/`:

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/v1/3rd/file/info` | Get file metadata |
| `POST` | `/v1/3rd/user/info` | Get user information by IDs |
| `POST` | `/v1/3rd/file/save` | Save new version of file |
| `POST` | `/v1/3rd/file/online` | Notify online collaborators |
| `GET` | `/v1/3rd/file/version/{version}` | Get specific file version |
| `PUT` | `/v1/3rd/file/rename` | Rename file |
| `POST` | `/v1/3rd/file/history` | Get file version history |
| `POST` | `/v1/3rd/file/new` | Create new file |
| `POST` | `/v1/3rd/onnotify` | Handle WPS callback notifications |

**Note**: These endpoints are called by WPS WebOffice service, not directly by your application.

## 📝 Implementation Guide

### Required Abstract Methods

You must implement the following methods in your handler service:

#### 1. `authUser($token): User`

Authenticate user by token and return User object.

```php
public function authUser($token): User
{
    // Decode and validate token
    $userData = $this->decodeToken($token);
    
    return new User(
        $userData['id'],
        $userData['name'],
        $userData['avatar_url']
    );
}
```

#### 2. `fileInfo($file_id): File`

Get file metadata by file ID.

```php
public function fileInfo($file_id): File
{
    $resource = WebOfficeResource::where('uuid', $file_id)->firstOrFail();
    
    $file = new File();
    $file->id = $resource->id;
    $file->uuid = $resource->uuid;
    $file->name = $resource->name;
    $file->version = $resource->version;
    $file->size = $resource->size;
    $file->suffix = $resource->suffix;
    $file->creator = $resource->creator;
    $file->create_time = $resource->created_at->timestamp;
    $file->modifier = $resource->modifier;
    $file->modify_time = $resource->updated_at->timestamp;
    $file->download_url = Storage::url($resource->path);
    
    return $file;
}
```

#### 3. `UserInfo(array $ids): Users`

Get user information by user IDs.

```php
public function UserInfo(array $ids): Users
{
    $users = new Users();
    $userModels = User::whereIn('id', $ids)->get();
    
    foreach ($userModels as $userModel) {
        $user = new User(
            $userModel->id,
            $userModel->name,
            $userModel->avatar_url
        );
        $users->push($user);
    }
    
    return $users;
}
```

#### 4. `save($file_id, $file, $user_id): File`

Save a new version of the file.

```php
public function save($file_id, $file, $user_id): File
{
    $resource = WebOfficeResource::where('uuid', $file_id)->firstOrFail();
    
    // Save uploaded file
    $path = $file->store('weboffice/files', 'public');
    
    // Update resource
    $resource->version = ($resource->version ?? 0) + 1;
    $resource->path = $path;
    $resource->size = $file->getSize();
    $resource->modifier = $user_id;
    $resource->save();
    
    // Create version record
    WebOfficeResourceVersion::create([
        'resource_id' => $resource->id,
        'version' => $resource->version,
        'name' => $resource->name,
        'url' => Storage::url($path),
        'size' => $file->getSize(),
        'modifier' => $user_id,
    ]);
    
    return $this->fileInfo($file_id);
}
```

#### 5. Other Methods

- `online()`: Track online collaborators
- `version($file_id, $version)`: Get specific version
- `rename($file_id, $name)`: Rename file
- `history($file_id, $offset, $count)`: Get version history
- `new($file_id, $file, $user_id)`: Create new file
- `onNotify()`: Handle WPS callbacks

See `EXAMPLE_IMPLEMENTATION.php` for complete examples.

## 📁 File Structure

### Models

#### WebOfficeResource

Polymorphic model for storing document resources:

```php
WebOfficeResource::create($type, $id, [
    'uuid' => 'unique-file-id',
    'name' => 'document.docx',
    'suffix' => 'docx',
    'size' => 1024,
    'version' => 1,
    'creator' => 1,
    'modifier' => 1,
]);
```

#### WebOfficeResourceVersion

Stores version history:

```php
WebOfficeResourceVersion::create([
    'resource_id' => 1,
    'version' => 2,
    'name' => 'document.docx',
    'url' => 'https://example.com/file.docx',
    'size' => 2048,
    'modifier' => 1,
]);
```

## 💡 Usage Examples

### Example 1: Generate Document View URL

```php
use App\Services\WebOfficeService;
use Eiixy\WebOffice\Models\WebOfficeResource;

$resource = WebOfficeResource::find(1);
$webOfficeService = app(WebOfficeService::class);

$file = $webOfficeService->fileInfo($resource->uuid);
$viewUrl = $webOfficeService->getFileUrl($file, auth()->id(), 'read');

// Use $viewUrl in your view
return view('document.view', ['url' => $viewUrl]);
```

### Example 2: Generate Document Edit URL

```php
$editUrl = $webOfficeService->getFileUrl($file, auth()->id(), 'write');
```

### Example 3: Add Watermark

```php
$file->setWatermark([
    'type' => 1,
    'value' => 'Confidential',
    'fillstyle' => 'rgba(192, 192, 192, 0.6)',
    'font' => 'bold 20px Arial',
    'rotate' => -0.7853982,
    'horizontal' => 50,
    'vertical' => 100,
]);

$url = $webOfficeService->getFileUrl($file, auth()->id(), 'read');
```

### Example 4: Configure User ACL

```php
$file->setUserAcl([
    'rename' => 1,    // Allow rename
    'history' => 1,    // Allow view history
    'copy' => 0,      // Disallow copy
    'export' => 1,    // Allow export
    'print' => 0,     // Disallow print
]);

$url = $webOfficeService->getFileUrl($file, auth()->id(), 'read');
```

### Example 5: Create New Document Resource

```php
use Eiixy\WebOffice\Models\WebOfficeResource;
use Illuminate\Http\UploadedFile;

$file = $request->file('document');
$uuid = Str::uuid();

WebOfficeResource::create('App\Models\Document', $documentId, [
    'uuid' => $uuid,
    'name' => $file->getClientOriginalName(),
    'suffix' => $file->getClientOriginalExtension(),
    'size' => $file->getSize(),
    'version' => 1,
    'creator' => auth()->id(),
    'modifier' => auth()->id(),
    'path' => $file->store('weboffice/files', 'public'),
]);
```

## 🔒 Security

### Signature Verification

The package automatically verifies all incoming requests from WPS using HMAC-SHA1 signature:

1. WPS sends requests with `_w_signature` parameter
2. Controller validates signature in constructor
3. Invalid signatures throw `WebOfficeException`

### Authentication

- Use secure token generation for `authUser()` method
- Validate tokens on every request
- Implement proper user permission checks

### Best Practices

1. **Never expose APPKEY**: Keep it in `.env` file only
2. **Validate file ownership**: Check user permissions before allowing access
3. **Sanitize file names**: Prevent path traversal attacks
4. **Rate limiting**: Implement rate limiting on callback endpoints
5. **HTTPS only**: Always use HTTPS in production

## 🐛 Troubleshooting

### Common Issues

#### 1. Signature Verification Failed

**Error**: `签名验证失败`

**Solution**: 
- Check that `WPS_APPKEY` in `.env` matches your WPS account
- Ensure server time is synchronized (signatures are time-sensitive)
- Verify request parameters are not being modified

#### 2. File Not Found

**Error**: `File not found`

**Solution**:
- Verify file exists in database
- Check `uuid` field matches
- Ensure migrations have been run

#### 3. Handler Class Not Found

**Error**: `Class not found`

**Solution**:
- Run `composer dump-autoload`
- Verify handler class path in `config/weboffice.php`
- Ensure handler extends `WebOfficeHandlerService`

#### 4. Route Not Found

**Error**: `404 Not Found`

**Solution**:
- Ensure service provider is registered
- Check routes are loaded: `php artisan route:list | grep wps`
- Verify route prefix matches WPS configuration

### Debug Mode

Enable Laravel debug mode to see detailed error messages:

```env
APP_DEBUG=true
```

## 📚 Additional Resources

- [WPS WebOffice Developer Documentation](https://open.wps.cn/)
- [Laravel Documentation](https://laravel.com/docs)
- [Example Implementation](./EXAMPLE_IMPLEMENTATION.php)
- [Setup Guide](./SETUP.md)

## 📄 License

This package is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).

## 👤 Author

**eiixy**
- Email: 990656271@qq.com

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## ⚠️ Important Notes

1. **WPS Account Required**: You must register at WPS Developer Platform to get `APPID` and `APPKEY`
2. **Callback URLs**: Configure callback URLs in your WPS developer dashboard
3. **HTTPS Required**: WPS requires HTTPS for production environments
4. **File Storage**: Ensure your file storage is accessible via HTTP/HTTPS for download URLs

## 📞 Support

For issues and questions:
- Open an issue on GitHub
- Contact: 990656271@qq.com

---

**Happy Coding! 🚀**
