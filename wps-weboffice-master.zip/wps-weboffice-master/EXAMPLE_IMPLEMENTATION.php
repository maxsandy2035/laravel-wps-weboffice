<?php
/**
 * Example Implementation of WebOfficeService
 * 
 * This is a basic example showing how to implement the abstract methods.
 * Copy this to your Laravel app's app/Services/WebOfficeService.php
 * and customize according to your business logic.
 */

namespace App\Services;

use Eiixy\WebOffice\Services\WebOfficeHandlerService;
use Eiixy\WebOffice\File;
use Eiixy\WebOffice\User;
use Eiixy\WebOffice\Users;
use Eiixy\WebOffice\Models\WebOfficeResource;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;

class WebOfficeService extends WebOfficeHandlerService
{
    /**
     * Authenticate user by token
     * @param string $token
     * @return User
     */
    public function authUser($token): User
    {
        // TODO: Implement your authentication logic
        // Example: Decode token, validate, get user from database
        // For now, returning a mock user
        return new User(
            'user_123',
            'Test User',
            'https://example.com/avatar.jpg'
        );
    }

    /**
     * Get file metadata
     * @param string $file_id
     * @return File
     */
    public function fileInfo($file_id): File
    {
        // TODO: Get file from database or storage
        $resource = WebOfficeResource::where('uuid', $file_id)->first();
        
        if (!$resource) {
            throw new \Exception('File not found');
        }

        $file = new File();
        $file->id = $resource->id;
        $file->uuid = $resource->uuid;
        $file->name = $resource->name;
        $file->version = $resource->version ?? 1;
        $file->size = $resource->size ?? 0;
        $file->suffix = $resource->suffix ?? 'docx';
        $file->creator = $resource->creator ?? 'system';
        $file->create_time = $resource->created_at->timestamp ?? time();
        $file->modifier = $resource->modifier ?? 'system';
        $file->modify_time = $resource->updated_at->timestamp ?? time();
        $file->download_url = $resource->download_url ?? Storage::url($resource->path);

        return $file;
    }

    /**
     * Get user information by IDs
     * @param array $ids
     * @return Users
     */
    public function UserInfo(array $ids): Users
    {
        // TODO: Get users from database
        $users = new Users();
        
        foreach ($ids as $id) {
            // Example: Get user from database
            $user = new User(
                $id,
                'User ' . $id,
                'https://example.com/avatar/' . $id . '.jpg'
            );
            $users->push($user);
        }

        return $users;
    }

    /**
     * Notify which users are currently collaborating on the file
     * @return void
     */
    public function online()
    {
        // TODO: Implement online user tracking
        // This could use Redis, database, or other storage
        // to track who is currently viewing/editing the file
    }

    /**
     * Save a new version of the file
     * @param string $file_id
     * @param UploadedFile $file
     * @param string $user_id
     * @return File
     */
    public function save($file_id, $file, $user_id): File
    {
        // TODO: Save uploaded file and create new version
        $resource = WebOfficeResource::where('uuid', $file_id)->first();
        
        if (!$resource) {
            throw new \Exception('File not found');
        }

        // Save file to storage
        $path = $file->store('weboffice/files', 'public');
        
        // Create new version record
        $resource->version = ($resource->version ?? 0) + 1;
        $resource->path = $path;
        $resource->size = $file->getSize();
        $resource->modifier = $user_id;
        $resource->save();

        return $this->fileInfo($file_id);
    }

    /**
     * Get specific version of file
     * @param string $file_id
     * @param int $version
     * @return File
     */
    public function version($file_id, $version): File
    {
        // TODO: Get specific version from database
        $resource = WebOfficeResource::where('uuid', $file_id)
            ->where('version', $version)
            ->first();

        if (!$resource) {
            throw new \Exception('Version not found');
        }

        $file = new File();
        $file->id = $resource->id;
        $file->uuid = $resource->uuid;
        $file->name = $resource->name;
        $file->version = $resource->version;
        $file->size = $resource->size ?? 0;
        $file->suffix = $resource->suffix ?? 'docx';
        $file->creator = $resource->creator ?? 'system';
        $file->create_time = $resource->created_at->timestamp ?? time();
        $file->modifier = $resource->modifier ?? 'system';
        $file->modify_time = $resource->updated_at->timestamp ?? time();
        $file->download_url = $resource->download_url ?? Storage::url($resource->path);

        return $file;
    }

    /**
     * Rename file
     * @param string $file_id
     * @param string $name
     * @return void
     */
    public function rename($file_id, $name)
    {
        // TODO: Update file name in database
        $resource = WebOfficeResource::where('uuid', $file_id)->first();
        
        if (!$resource) {
            throw new \Exception('File not found');
        }

        $resource->name = $name;
        $resource->save();
    }

    /**
     * Get file history versions
     * @param string $file_id
     * @param int $offset
     * @param int $count
     * @return array
     */
    public function history($file_id, $offset, $count)
    {
        // TODO: Get version history from database
        $resources = WebOfficeResource::where('uuid', $file_id)
            ->orderBy('version', 'desc')
            ->offset($offset)
            ->limit($count)
            ->get();

        $histories = [];
        foreach ($resources as $resource) {
            $file = new File();
            $file->id = $resource->id;
            $file->uuid = $resource->uuid;
            $file->name = $resource->name;
            $file->version = $resource->version;
            $file->size = $resource->size ?? 0;
            $file->modifier = $resource->modifier ?? 'system';
            $file->modify_time = $resource->updated_at->timestamp ?? time();
            $histories[] = $file->toArray();
        }

        return $histories;
    }

    /**
     * Create new file
     * @param string $file_id
     * @param UploadedFile $file
     * @param string $user_id
     * @return File
     */
    public function new($file_id, $file, $user_id): File
    {
        // TODO: Create new file record
        $path = $file->store('weboffice/files', 'public');
        
        $resource = WebOfficeResource::create([
            'uuid' => $file_id,
            'name' => $file->getClientOriginalName(),
            'path' => $path,
            'size' => $file->getSize(),
            'suffix' => $file->getClientOriginalExtension(),
            'version' => 1,
            'creator' => $user_id,
            'modifier' => $user_id,
        ]);

        return $this->fileInfo($file_id);
    }

    /**
     * Handle callback notifications
     * @return void
     */
    public function onNotify()
    {
        // TODO: Handle WPS callback notifications
        // This method is called when WPS sends notifications
        // about file changes, user actions, etc.
    }
}


