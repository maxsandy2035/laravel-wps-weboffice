# Setup Guide for WPS Web Office Package

## Prerequisites

This is a Laravel package that requires:
- **PHP** >= 7.1.3
- **Composer** (PHP dependency manager)
- **Laravel Framework** (5.5, 6.x, or 7.x)

## Installation Steps

### 1. Install PHP and Composer

**Windows:**
- Download PHP from: https://windows.php.net/download/
- Download Composer from: https://getcomposer.org/download/
- Add PHP and Composer to your system PATH

**Or use XAMPP/WAMP:**
- XAMPP includes PHP: https://www.apachefriends.org/
- Then install Composer separately

### 2. Create a Laravel Application

```bash
composer create-project laravel/laravel wps-app
cd wps-app
```

### 3. Install This Package

Since this is the package source code, you have two options:

**Option A: Install as local package**
```bash
# In your Laravel app's composer.json, add:
"repositories": [
    {
        "type": "path",
        "url": "../wps-weboffice-master"
    }
],
"require": {
    "eiixy/wps-weboffice": "*"
}
```

**Option B: Copy package to vendor (for development)**
```bash
# Copy this entire directory to your Laravel app's vendor/eiixy/wps-weboffice directory
```

### 4. Register the Service Provider

In `config/app.php`, add to the `providers` array:
```php
Eiixy\WebOffice\Providers\WebOfficeServiceProvider::class,
```

### 5. Publish Configuration

```bash
php artisan vendor:publish --provider="Eiixy\WebOffice\Providers\WebOfficeServiceProvider"
```

### 6. Configure Environment Variables

Add to your `.env` file:
```
WPS_APPID=your_app_id_here
WPS_APPKEY=your_app_key_here
WPS_DOMAINS_VIEW=https://wwo.wps.cn/office
```

### 7. Run Migrations

```bash
php artisan migrate
```

### 8. Implement the Handler Service

Create `app/Services/WebOfficeService.php` and implement all abstract methods from `WebOfficeHandlerService`.

### 9. Start the Server

```bash
php artisan serve
```

The API endpoints will be available at:
- `http://localhost:8000/v1/3rd/file/info`
- `http://localhost:8000/v1/3rd/user/info`
- etc.

## Quick Test Setup

If you want to test the package quickly, you'll need to implement the abstract methods in `WebOfficeService` class.


